{
  // Array
  const fruits: string[] = ["🍎", "🍌"];
  const scores: Array<number> = [1, 3, 4];
  // readonly는 ~[] 이런 방식으로만 가능함 그래서 첫번째 버전으로 작성하는것이 더 좋음
  function printArray(fruits: readonly string[]) {}

  // Tuple -> interface, type alias, class
  // tuple은 별로 안좋으므로 화살표 옆의 것으로 사용하는걸 권장함
  let student: [string, number];
  student = ["name", 123];
  student[0]; // name
  student[1]; // 123
  const [name, age] = student;
}
