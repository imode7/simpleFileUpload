{
  /**
   * Union Types: OR
   */
  type Direction = "left" | "right" | "up" | "down";
  function move(direction: Direction) {
    console.log(direction);
  }
  //   move("down");

  // function: login -> success, fail
  type SuccessState = {
    response: {
      body: string;
    };
  };
  type FailState = {
    reason: string;
  };
  type LoginState = SuccessState | FailState;
  function login(id: string, password: string): LoginState {
    return {
      response: {
        body: "logged in!",
      },
      /* reason: "why why!!!", */
    };
  }

  // success -> 🎉 body
  // fail -> 😭 reason
  // printLoginState(state: LoginState)
  function printLoginState(state: LoginState) {
    if ("response" in state) {
      console.log(`🎉 ${state.response.body}`);
    } else {
      console.log(`😭 ${state.reason}`);
    }
  }
  const success: SuccessState = {
    response: {
      body: "🎉 success",
    },
  };
  const fail: FailState = {
    reason: `😭 too sad..`,
  };
  printLoginState(success);
  printLoginState(fail);
}
