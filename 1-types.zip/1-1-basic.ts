{
  // JavaScript
  // let
  let name = "hello";
  name = "hi!";

  // const
  const age = 5;
}
{
  /**
   * Primitive(원시타입): number, string, boolean, bigint, symbol, null, undefined...
   * Object(객체타입): array, function...
   */

  // number
  const num: number = -6;

  // string
  const str: string = "hello";

  // boolean
  const bool: boolean = true;

  // undefined
  let name: undefined; // 💩
  let age: number | undefined;
  age = undefined;
  age = 1;
  function find(): number | undefined {
    return undefined;
  }

  // null
  let person: null;
  let person2: string | null;

  // unknown 과 any는 가급적 쓰지 않는것이 좋음
  // unknown 💩 => 모가 들어올지 몰랑~ 다됑~ (왠만하면 쓰지말것)
  let notSure: unknown = 0;
  notSure = "he";
  notSure = true;

  // any 💩
  let anything: any = 0;
  anything = "hello";

  // void
  function printing(): void {
    console.log("hello");
    return;
  }

  let unusable: void = undefined; //💩

  // never
  function throwError(message: string): never {
    // message -> server(log)
    throw new Error(message);
    while (true) {}
  }
  let neverEnding: never; // 💩

  // object
  let obj: object; // 💩
  function acceptSomeObject(obj: object) {}
  acceptSomeObject({ name: "ellie" });
  acceptSomeObject({ animal: "dog" });
}
